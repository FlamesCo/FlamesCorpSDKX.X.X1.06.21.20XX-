import cmd

# Terminal class
class Terminal(cmd.Cmd):
    prompt = '> '

    # Command to read a markdown file
    def do_read_md(self, args):
        pass

    # Command to write to a markdown file
    def do_write_md(self, args):
        pass

    # Command to modify a markdown file
    def do_modify_md(self, args):
        pass

    # Command to make a request to the Codex API
    def do_codex_request(self, args):
        pass

    # Help command
    def do_help(self, args):
        pass

    # Error handling
    def default(self, line):
        print('Invalid command: {}'.format(line))

# Main function
if __name__ == '__main__':
    Terminal().cmdloop()